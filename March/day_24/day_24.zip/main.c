#include "tabela_hash.c"

int main(int argc, char const *argv[])
{
    est_tabela_hash tab;
    iniciar_tabela(&tab);

    
    return 0;
}
